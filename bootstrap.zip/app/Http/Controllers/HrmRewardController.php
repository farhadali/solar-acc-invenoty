<?php

namespace App\Http\Controllers;

use App\Models\hrm\HrmReward;
use Illuminate\Http\Request;

class HrmRewardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\hrm\HrmReward  $hrmReward
     * @return \Illuminate\Http\Response
     */
    public function show(HrmReward $hrmReward)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\hrm\HrmReward  $hrmReward
     * @return \Illuminate\Http\Response
     */
    public function edit(HrmReward $hrmReward)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\hrm\HrmReward  $hrmReward
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, HrmReward $hrmReward)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\hrm\HrmReward  $hrmReward
     * @return \Illuminate\Http\Response
     */
    public function destroy(HrmReward $hrmReward)
    {
        //
    }
}
