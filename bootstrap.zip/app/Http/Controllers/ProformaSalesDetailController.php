<?php

namespace App\Http\Controllers;

use App\Models\ProformaSalesDetail;
use Illuminate\Http\Request;

class ProformaSalesDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ProformaSalesDetail  $proformaSalesDetail
     * @return \Illuminate\Http\Response
     */
    public function show(ProformaSalesDetail $proformaSalesDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ProformaSalesDetail  $proformaSalesDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(ProformaSalesDetail $proformaSalesDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ProformaSalesDetail  $proformaSalesDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProformaSalesDetail $proformaSalesDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ProformaSalesDetail  $proformaSalesDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProformaSalesDetail $proformaSalesDetail)
    {
        //
    }
}
