<?php

namespace App\Http\Controllers;

use App\Models\hrm\HrmLeavebalance;
use Illuminate\Http\Request;

class HrmLeavebalanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\hrm\HrmLeavebalance  $hrmLeavebalance
     * @return \Illuminate\Http\Response
     */
    public function show(HrmLeavebalance $hrmLeavebalance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\hrm\HrmLeavebalance  $hrmLeavebalance
     * @return \Illuminate\Http\Response
     */
    public function edit(HrmLeavebalance $hrmLeavebalance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\hrm\HrmLeavebalance  $hrmLeavebalance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, HrmLeavebalance $hrmLeavebalance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\hrm\HrmLeavebalance  $hrmLeavebalance
     * @return \Illuminate\Http\Response
     */
    public function destroy(HrmLeavebalance $hrmLeavebalance)
    {
        //
    }
}
