<?php

namespace App\Http\Controllers;

use App\Models\hrm\HrmSstructuredetails;
use Illuminate\Http\Request;

class HrmSstructuredetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\hrm\HrmSstructuredetails  $hrmSstructuredetails
     * @return \Illuminate\Http\Response
     */
    public function show(HrmSstructuredetails $hrmSstructuredetails)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\hrm\HrmSstructuredetails  $hrmSstructuredetails
     * @return \Illuminate\Http\Response
     */
    public function edit(HrmSstructuredetails $hrmSstructuredetails)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\hrm\HrmSstructuredetails  $hrmSstructuredetails
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, HrmSstructuredetails $hrmSstructuredetails)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\hrm\HrmSstructuredetails  $hrmSstructuredetails
     * @return \Illuminate\Http\Response
     */
    public function destroy(HrmSstructuredetails $hrmSstructuredetails)
    {
        //
    }
}
