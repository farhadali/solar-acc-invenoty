<?php

namespace App\Http\Controllers;

use App\Models\ItemInventory;
use Illuminate\Http\Request;

class ItemInventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ItemInventory  $itemInventory
     * @return \Illuminate\Http\Response
     */
    public function show(ItemInventory $itemInventory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ItemInventory  $itemInventory
     * @return \Illuminate\Http\Response
     */
    public function edit(ItemInventory $itemInventory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ItemInventory  $itemInventory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ItemInventory $itemInventory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ItemInventory  $itemInventory
     * @return \Illuminate\Http\Response
     */
    public function destroy(ItemInventory $itemInventory)
    {
        //
    }
}
