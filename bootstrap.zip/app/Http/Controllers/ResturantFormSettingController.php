<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ResturantFormSettingController extends Controller
{
    //
}
