<?php

namespace App\Http\Controllers;

use App\Models\hrm\HrmItaxledger;
use Illuminate\Http\Request;

class HrmItaxledgerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\hrm\HrmItaxledger  $hrmItaxledger
     * @return \Illuminate\Http\Response
     */
    public function show(HrmItaxledger $hrmItaxledger)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\hrm\HrmItaxledger  $hrmItaxledger
     * @return \Illuminate\Http\Response
     */
    public function edit(HrmItaxledger $hrmItaxledger)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\hrm\HrmItaxledger  $hrmItaxledger
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, HrmItaxledger $hrmItaxledger)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\hrm\HrmItaxledger  $hrmItaxledger
     * @return \Illuminate\Http\Response
     */
    public function destroy(HrmItaxledger $hrmItaxledger)
    {
        //
    }
}
